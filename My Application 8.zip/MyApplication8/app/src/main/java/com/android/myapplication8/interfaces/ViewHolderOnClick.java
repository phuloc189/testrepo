package com.android.myapplication8.interfaces;

import com.android.myapplication8.Util;

public interface ViewHolderOnClick {
    void onItemClick(Util.ClickEvent event, int position);
}
