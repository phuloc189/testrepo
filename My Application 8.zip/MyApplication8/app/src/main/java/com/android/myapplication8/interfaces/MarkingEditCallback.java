package com.android.myapplication8.interfaces;

import com.android.myapplication8.Util;

public interface MarkingEditCallback {

    void onMarkingChanged (Util.DialogType dialogType, int newValue);
}
